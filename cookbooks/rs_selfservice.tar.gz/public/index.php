<?php

require_once __DIR__ . '/../application/scripts/bootstrapEnvironment.php';

// $application is instantiated in bootstrapEnvironment above
$application->bootstrap()
            ->run();