function appendErrorMessage(message) {
  $('#messages').append('<p class="error">' + message + '</p>');
}